<?php
  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Catálogo de Productos
        <small></small>
      </h1>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Maneje el Catálogo de Productos</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="registros" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Codigo Producto</th>
                  <th>Material</th>
                  <th>Precio c/u</th>
                  <th>Ancho(cm)</th>
                  <th>Largo(cm)</th>
                  <th>Estatus</th>
                  <th></th>
                </tr>
                </thead>
                <tbody>
                        <?php
                              try{
                                  $sql = "SELECT id_producto, codigo_producto, material_producto, precio_producto, ancho_producto, largo_producto, estatus_producto";
                                  $sql .= " FROM producto";
                                  $sql .= " ORDER BY id_producto";
                                  $resultado = $conn->query($sql);
                              }catch(Exception $e){
                                  $error = $e->getMessage();
                                  echo $error;
                              }
                              while ($producto = $resultado->fetch_assoc() ){ ?>
                                  <tr>
                                      <td><?php echo $producto['codigo_producto']; ?></td>
                                      <td><?php echo $producto['material_producto']; ?></td>
                                      <td><?php echo $producto['precio_producto']; ?></td>
                                      <td><?php echo $producto['ancho_producto']; ?></td>
                                      <td><?php echo $producto['largo_producto']; ?></td>
                                      <td><?php 
                                          if ($producto['estatus_producto'] == 1)
                                            echo 'Existente'; 
                                          else
                                            echo 'No Existente'; ?>
                                      </td>
                                      <td>
                                          <a href="editar-producto.php?id=<?php echo $producto['id_producto']; ?>" class="">
                                          Editar
                                          <i class="fa fa-pencil"></i>
                                          </a>
                                          <a href="#" data-id="<?php echo $producto['id_barra'];  ?>" data-tipo="categoria" class="borrar_registro">
                                          Eliminar
                                          <i class="fa fa-trash"></i>
                                          </a>

                                      </td>

                                  </tr>
                              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Codigo Producto</th>
                  <th>Material</th>
                  <th>Precio c/u</th>
                  <th>Ancho(cm)</th>
                  <th>Largo(cm)</th>
                  <th>Estatus</th>
                  <th></th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
  ?>


