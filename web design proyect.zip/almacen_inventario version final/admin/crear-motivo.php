<?php
  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';

?>




  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Agregar Pedido de Motivo
        <small>llene el formulario para agregar un pedido de motivo</small>
      </h1>
    </section>

      <div class="row">
          <div class="col-md-8">


              <!-- Main content -->
              <section class="content">

                <!-- Default box -->
                <div class="box">
                  <div class="box-header with-border">
                    <h3 class="box-title">Agregar Pedido de Motivo</h3>
                  </div>
                  <div class="box-body">

                  <form role="form" name="guardar-registro" id="guardar-registro" method="post" action="modelo-evento.php">
                        
                              <div class="form-group">
                                    <label for="nombre">NumeroMotivo:</label>
                                    <input type="text" class="form-control" id="titulo_evento" name="titulo_evento" placeholder="" value="">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Codigo de Producto:</label>
                                    <select name="categoria_evento" class="form-control seleccionar" id="">
                                    <option value="0">- Seleccione -</option>
                                        <?php
                                          try{
                                            $sql = "SELECT * FROM producto";
                                            $resultado = $conn->query($sql);
                                            while($select = $resultado->fetch_assoc()) { ?>
                                              
                                                    <option value="<?php echo $select['id_producto']; ?>">
                                                        <?php  echo $select['codigo_producto']; ?>
                                                    </option>
                                                    <?php
                                            }
                                          } catch (Exception $e){
                                            echo "Error: " . $e->getMessage();
                                          }
                                        ?>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">PrecioTrabajo:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">FechaInicio:</label>

                                <div class="input-group date">
                                <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="fecha" name="fecha_evento" value="">
                                </div>
                            <!-- /.input group -->
                              </div>

                              <div class="form-group">
                                    <label for="nombre">FechaFin:</label>
   
                                <div class="input-group date">
                                <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="fecha" name="fecha_evento" value="">
                                </div>
                            <!-- /.input group -->
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Cliente:</label>
                                    <select name="categoria_evento" class="form-control seleccionar" id="">
                                    <option value="0">- Seleccione -</option>
                                        <?php
                                          try{
                                            $sql = "SELECT * FROM cliente";
                                            $resultado = $conn->query($sql);
                                            while($select = $resultado->fetch_assoc()) { ?>
                                                    
                                                    <option value="<?php echo $select['id_cliente']; ?>">
                                                        <?php  echo $select['rfc']; ?>
                                                    </option>
                                                    <?php
                                            }
                                          } catch (Exception $e){
                                            echo "Error: " . $e->getMessage();
                                          }
                                        ?>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">AnchoMotivo(cm):</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">LargoMotivo(cm):</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">MariaLuisa:</label>
                                    <select name="categoria_evento" class="form-control" id="">
                                    <option value="0">- Seleccione -</option>
                                    <option value="Si" >Si </option>
                                    <option value="No">No</option>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Estado:</label>
                                    <select name="categoria_evento" class="form-control" id="">
                                    <option value="0">- Seleccione -</option>
                                    <option value="Si" >Completado </option>
                                    <option value="No">No Completado</option>
                                    </select></div>


                        <!-- /.box-body -->

                        <div class="box-footer">
                          <input type="hidden" name="registro" value="actualizar">
                          <input type="hidden" name="id_registro" value="<?php echo $id; ?>">
                          <button type="submit" class="btn btn-primary" id="crear_registro">Guardar</button>
                        </div>
                      </form>
                  </div>
                  <!-- /.box-body -->

                </div>
                <!-- /.box -->

              </section>
              <!-- /.content -->

          </div>
      </div>
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
  ?>

