<?php
  if($_GET['id']){
    $id = $_GET['id'];
  }

  if(!filter_var($id, FILTER_VALIDATE_INT)):
        die("Error");
  else:

  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';

?>




  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Modificar Pedido de Motivo
        <small>llene el formulario para modificar un registro de pedido de motivo</small>
      </h1>
    </section>

      <div class="row">
          <div class="col-md-8">


              <!-- Main content -->
              <section class="content">

                <!-- Default box -->
                <div class="box">
                  <div class="box-header with-border">
                    <h3 class="box-title">Modificar Pedido de Motivo</h3>
                  </div>
                  <div class="box-body">
                    <?php
                        $sql = "SELECT * FROM motivos WHERE id_motivo = $id ";
                        $resultado = $conn->query($sql);
                        $motivo = $resultado->fetch_assoc();
                    ?>

                  <form role="form" name="guardar-registro" id="guardar-registro" method="post" action="modelo-evento.php">
                        
                              <div class="form-group">
                                    <label for="nombre">NumeroMotivo:</label>
                                    <input type="text" class="form-control" id="titulo_evento" name="titulo_evento" placeholder="" value="<?php echo $motivo['num_motivo'] ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Codigo de Producto:</label>
                                    <select name="categoria_evento" class="form-control seleccionar" id="">
                                    <option value="0">- Seleccione -</option>
                                        <?php
                                          try{
                                            $producto_actual = $motivo['id_producto'];
                                            $sql = "SELECT * FROM producto";
                                            $resultado = $conn->query($sql);
                                            while($select = $resultado->fetch_assoc()) { 
                                                if($select['id_producto'] == $producto_actual) { ?>
                                                    <option value="<?php echo $select['id_producto']; ?>" selected>
                                                        <?php  echo $select['codigo_producto']; ?>
                                                    </option>
                                                <?php } else{ ?>
                                                    <option value="<?php echo $select['id_producto']; ?>">
                                                        <?php  echo $select['codigo_producto']; ?>
                                                    </option>
                                                <?php } 
                                            }
                                          } catch (Exception $e){
                                            echo "Error: " . $e->getMessage();
                                          }
                                        ?>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">PrecioTrabajo:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $motivo['precio_trabajo']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">FechaInicio:</label>
                                    <?php
                                    $fecha = $motivo['fecha_pedido'];
                                    $fecha_formato = date('Y/m/d', strtotime($fecha));
                                ?>

                                <div class="input-group date">
                                <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="fecha" name="fecha_evento" value="<?php echo $fecha_formato; ?>">
                                </div>
                            <!-- /.input group -->
                              </div>

                              <div class="form-group">
                                    <label for="nombre">FechaFin:</label>
                                    <?php
                                    $fecha = $motivo['fecha_entrega'];
                                    $fecha_formato = date('Y/m/d', strtotime($fecha));
                                ?>

                                <div class="input-group date">
                                <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="fecha" name="fecha_evento" value="<?php echo $fecha_formato; ?>">
                                </div>
                            <!-- /.input group -->
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Cliente:</label>
                                    <select name="categoria_evento" class="form-control seleccionar" id="">
                                    <option value="0">- Seleccione -</option>
                                        <?php
                                          try{
                                            $cliente_actual = $motivo['id_cliente'];
                                            $sql = "SELECT * FROM cliente";
                                            $resultado = $conn->query($sql);
                                            while($select = $resultado->fetch_assoc()) { 
                                                if($select['id_cliente'] == $cliente_actual) { ?>
                                                    <option value="<?php echo $select['id_cliente']; ?>" selected>
                                                        <?php  echo $select['rfc']; ?>
                                                    </option>
                                                <?php } else{ ?>
                                                    <option value="<?php echo $select['id_cliente']; ?>">
                                                        <?php  echo $select['rfc']; ?>
                                                    </option>
                                                <?php } 
                                            }
                                          } catch (Exception $e){
                                            echo "Error: " . $e->getMessage();
                                          }
                                        ?>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">AnchoMotivo(cm):</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $motivo['ancho_motivo']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">LargoMotivo(cm):</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $motivo['largo_motivo']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">MariaLuisa:</label>
                                    <select name="categoria_evento" class="form-control" id="">
                                    <option value="0">- Seleccione -</option>
                                    <option value="Si" selected>Si </option>
                                    <option value="No">No</option>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Estado:</label>
                                    <select name="categoria_evento" class="form-control" id="">
                                    <option value="0">- Seleccione -</option>
                                    <option value="Si" selected>Completado </option>
                                    <option value="No">No Completado</option>
                                    </select></div>


                        <!-- /.box-body -->

                        <div class="box-footer">
                          <input type="hidden" name="registro" value="actualizar">
                          <input type="hidden" name="id_registro" value="<?php echo $id; ?>">
                          <button type="submit" class="btn btn-primary" id="crear_registro">Guardar</button>
                        </div>
                      </form>
                  </div>
                  <!-- /.box-body -->

                </div>
                <!-- /.box -->

              </section>
              <!-- /.content -->

          </div>
      </div>
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
    endif;
  ?>

