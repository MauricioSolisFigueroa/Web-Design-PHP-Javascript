<?php
  if($_GET['id']){
    $id = $_GET['id'];
  }

  if(!filter_var($id, FILTER_VALIDATE_INT)):
        die("Error");
  else:

  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';

?>




  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Modificar Pedido de Motivo
        <small>llene el formulario para modificar un registro de pedido de mercancia</small>
      </h1>
    </section>

      <div class="row">
          <div class="col-md-8">


              <!-- Main content -->
              <section class="content">

                <!-- Default box -->
                <div class="box">
                  <div class="box-header with-border">
                    <h3 class="box-title">Modificar Pedido de Motivo</h3>
                  </div>
                  <div class="box-body">
                    <?php
                        $sql = "SELECT * FROM pedidos_a_proveedor WHERE id_pedido = $id ";
                        $resultado = $conn->query($sql);
                        $motivo = $resultado->fetch_assoc();
                    ?>

                  <form role="form" name="guardar-registro" id="guardar-registro" method="post" action="modelo-evento.php">
                        
                              <div class="form-group">
                                    <label for="nombre">Codigo de Producto:</label>
                                    <select name="categoria_evento" class="form-control seleccionar" id="">
                                    <option value="0">- Seleccione -</option>
                                        <?php
                                          try{
                                            $producto_actual = $motivo['id_producto'];
                                            $sql = "SELECT * FROM producto";
                                            $resultado = $conn->query($sql);
                                            while($select = $resultado->fetch_assoc()) { 
                                                if($select['id_producto'] == $producto_actual) { ?>
                                                    <?php
                                                    $material = $select['material_producto'];
                                                    $precio = $select['precio_producto'];
                                                    ?>
                                                    <option value="<?php echo $select['id_producto']; ?>" selected>
                                                        <?php  echo $select['codigo_producto']; ?>
                                                    </option>
                                                <?php } else{ ?>
                                                    <option value="<?php echo $select['id_producto']; ?>">
                                                        <?php  echo $select['codigo_producto']; ?>
                                                    </option>
                                                <?php } 
                                            }
                                          } catch (Exception $e){
                                            echo "Error: " . $e->getMessage();
                                          }
                                        ?>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Material:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $material; ?> ">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Precio c/u:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $precio; ?> ">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">CantidadBarras:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $motivo['cantidad_pedido']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">CostoPedido:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $motivo['costo_pedido']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">FechaInicio:</label>
                                    <?php
                                    $fecha = $motivo['fecha_pedido'];
                                    $fecha_formato = date('Y/m/d', strtotime($fecha));
                                ?>

                                <div class="input-group date">
                                <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="fecha" name="fecha_evento" value="<?php echo $fecha_formato; ?>">
                                </div>
                            <!-- /.input group -->
                              </div>

                              <div class="form-group">
                                    <label for="nombre">FechaFin:</label>
                                    <?php
                                    $fecha = $motivo['fecha_entrega'];
                                    $fecha_formato = date('Y/m/d', strtotime($fecha));
                                ?>

                                <div class="input-group date">
                                <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="fecha" name="fecha_evento" value="<?php echo $fecha_formato; ?>">
                                </div>
                            <!-- /.input group -->
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Proveedor:</label>
                                    <select name="categoria_evento" class="form-control seleccionar" id="">
                                    <option value="0">- Seleccione -</option>
                                        <?php
                                          try{
                                            $proveedor_actual = $motivo['id_proveedor'];
                                            $sql = "SELECT * FROM proveedor";
                                            $resultado = $conn->query($sql);
                                            while($select = $resultado->fetch_assoc()) { 
                                                if($select['id_proveedor'] == $proveedor_actual) { ?>
                                                    <option value="<?php echo $select['id_proveedor']; ?>" selected>
                                                        <?php  echo $select['codigo_proveedor']; ?>
                                                    </option>
                                                <?php } else{ ?>
                                                    <option value="<?php echo $select['id_proveedor']; ?>">
                                                        <?php  echo $select['codigo_proveedor']; ?>
                                                    </option>
                                                <?php } 
                                            }
                                          } catch (Exception $e){
                                            echo "Error: " . $e->getMessage();
                                          }
                                        ?>
                                    </select>
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Estado:</label>
                                    <select name="categoria_evento" class="form-control" id="">
                                    <option value="0">- Seleccione -</option>
                                    <option value="Si" selected>Completado </option>
                                    <option value="No">No Completado</option>
                                    </select></div>


                        <!-- /.box-body -->

                        <div class="box-footer">
                          <input type="hidden" name="registro" value="actualizar">
                          <input type="hidden" name="id_registro" value="<?php echo $id; ?>">
                          <button type="submit" class="btn btn-primary" id="crear_registro">Guardar</button>
                        </div>
                      </form>
                  </div>
                  <!-- /.box-body -->

                </div>
                <!-- /.box -->

              </section>
              <!-- /.content -->

          </div>
      </div>
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
    endif;
  ?>

