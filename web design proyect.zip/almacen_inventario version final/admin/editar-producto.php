<?php
  if($_GET['id']){
    $id = $_GET['id'];
  }

  if(!filter_var($id, FILTER_VALIDATE_INT)):
        die("Error");
  else:

  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';

?>




  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Modificar Producto
        <small>llene el formulario para modificar un producto</small>
      </h1>
    </section>

      <div class="row">
          <div class="col-md-8">


              <!-- Main content -->
              <section class="content">

                <!-- Default box -->
                <div class="box">
                  <div class="box-header with-border">
                    <h3 class="box-title">Modificar Producto</h3>
                  </div>
                  <div class="box-body">
                    <?php
                        $sql = "SELECT * FROM producto WHERE id_producto = $id ";
                        $resultado = $conn->query($sql);
                        $producto = $resultado->fetch_assoc();
                    ?>

                  <form role="form" name="guardar-registro" id="guardar-registro" method="post" action="modelo-evento.php">
                        
                              <div class="form-group">
                                    <label for="nombre">Codigo de Barra:</label>
                                    <input readonly="readonly" type="text" class="form-control" id="titulo_evento" name="titulo_evento" placeholder="" value="<?php echo $producto['codigo_producto']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Material:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $producto['material_producto']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Precio:</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $producto['precio_producto']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Ancho(cm):</label>
                                    <input type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $producto['ancho_producto']; ?>">
                              </div>

                              <div class="form-group">
                                    <label for="nombre">Largo(cm):</label>
                                    <input readonly="readonly" type="text" class="form-control" id="" name="" placeholder="" value="<?php echo $producto['largo_producto']; ?>">
                              </div>

                        <!-- /.box-body -->

                        <div class="box-footer">
                          <input type="hidden" name="registro" value="actualizar">
                          <input type="hidden" name="id_registro" value="<?php echo $id; ?>">
                          <button type="submit" class="btn btn-primary" id="crear_registro">Guardar</button>
                        </div>
                      </form>
                  </div>
                  <!-- /.box-body -->

                </div>
                <!-- /.box -->

              </section>
              <!-- /.content -->

          </div>
      </div>
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
    endif;
  ?>

