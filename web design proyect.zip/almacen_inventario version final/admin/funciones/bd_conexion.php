<?php 
    $conn = new mysqli('localhost', 'root', 'root', 'inventarios');

    if($conn->connect_error){
        echo $error -> $conn->connect_error;
    }

?>