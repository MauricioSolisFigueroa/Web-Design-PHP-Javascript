<?php
  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Inventario de Barras
        <small></small>
      </h1>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Visualice el inventario de barras</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="registros" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>CodigoProducto</th>
                  <th>CantidadInventario</th>
                  <th>Ubicacion</th>
                  <th>TipoInventario</th>
                  <th>Estatus</th>
                </tr>
                </thead>
                <tbody>
                        <?php
                              try{
                                  $sql = "SELECT id_inventario, codigo_producto, cantidad_inventario, nombre_area, nombre_inventario, estatus_inventario";
                                  $sql .= " FROM inventario_barras";
                                  $sql .= " INNER JOIN area";
                                  $sql .= " ON inventario_barras.id_area = area.id_area";
                                  $sql .= " INNER JOIN producto";
                                  $sql .= " ON inventario_barras.id_producto = producto.id_producto";
                                  $sql .= " INNER JOIN tipo_inventario";
                                  $sql .= " ON inventario_barras.id_tipo_inventario = tipo_inventario.id_tipo_inventario";
                                  $sql .= " ORDER BY id_inventario";
                                  $resultado = $conn->query($sql);
                              }catch(Exception $e){
                                  $error = $e->getMessage();
                                  echo $error;
                              }
                              while ($producto = $resultado->fetch_assoc() ){ ?>
                                  <tr>
                                      <td><?php echo $producto['codigo_producto']; ?></td>
                                      <td><?php echo $producto['cantidad_inventario']; ?></td>
                                      <td><?php echo $producto['nombre_area']; ?></td>
                                      <td><?php echo $producto['nombre_inventario']; ?></td>
                                      <td><?php 
                                          if ($producto['estatus_inventario'] == 1)
                                            echo 'Existente'; 
                                          else
                                            echo 'No Existente'; ?>
                                      </td>

                                  </tr>
                              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Codigo Producto</th>
                  <th>Cantidad</th>
                  <th>Ubicacion</th>
                  <th>TipoInventario</th>
                  <th>Estatus</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
  ?>


