<?php
  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Listado de Pedidos de Mercancia Recibidos 
        <small></small>
      </h1>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Verfifique el estado de los pedidos de mercancia recibidos </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="registros" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Codigo Producto</th>
                  <th>Material</th>
                  <th>Precio c/u</th>
                  <th>CantidadBarras</th>
                  <th>CostoPedido</th>
                  <th>FechaInicio</th>
                  <th>FechaFin</th>
                  <th>Proveedor</th>
                  <th>Estatus</th>
                  <th></th>
                </tr>
                </thead>
                <tbody>
                        <?php
                              try{
                                  $sql = "SELECT id_pedido, codigo_producto, material_producto, precio_producto, cantidad_pedido, costo_pedido, fecha_pedido, fecha_entrega, estatus_pedido, codigo_proveedor";
                                  $sql .= " FROM pedidos_a_proveedor";
                                  $sql .= " INNER JOIN producto";
                                  $sql .= " ON pedidos_a_proveedor.id_producto = producto.id_producto";
                                  $sql .= " INNER JOIN proveedor";
                                  $sql .= " ON pedidos_a_proveedor.id_proveedor = proveedor.id_proveedor";
                                  $sql .= " ORDER BY id_pedido";
                                  $resultado = $conn->query($sql);
                              }catch(Exception $e){
                                  $error = $e->getMessage();
                                  echo $error;
                              }
                              while ($pedido = $resultado->fetch_assoc() ){ ?>
                                  <tr>
                                      <td><?php echo $pedido['codigo_producto']; ?></td>
                                      <td><?php echo $pedido['material_producto']; ?></td>
                                      <td><?php echo $pedido['precio_producto']; ?></td>
                                      <td><?php echo $pedido['cantidad_pedido']; ?></td>
                                      <td><?php echo $pedido['costo_pedido']; ?></td>
                                      <td><?php echo $pedido['fecha_pedido']; ?></td>
                                      <td><?php echo $pedido['fecha_entrega']; ?></td>
                                      <td><?php echo $pedido['codigo_proveedor']; ?></td>
                                      <td><?php
                                        if ($pedido['estatus_pedido'] == 0)
                                          echo 'Completado';
                                        else
                                          echo 'No Completado'; ?>
                                       </td>
                                      <td>
                                          <a href="editar-pedido-proveedor.php?id=<?php echo $pedido['id_pedido']; ?>" class="">
                                          Editar
                                          <i class="fa fa-pencil"></i>
                                          </a>
                                          <a href="#" data-id="<?php echo $producto['id_barra'];  ?>" data-tipo="categoria" class="borrar_registro">
                                          Eliminar
                                          <i class="fa fa-trash"></i>
                                          </a>
            
                                      </td>

                                  </tr>
                              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Codigo Barra</th>
                  <th>Material</th>
                  <th>Precio c/u</th>
                  <th>CantidadBarras</th>
                  <th>CostoPedido</th>
                  <th>FechaInicio</th>
                  <th>FechaFin</th>
                  <th>Proveedor</th>
                  <th>Estatus</th>
                  <th></th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
  ?>


