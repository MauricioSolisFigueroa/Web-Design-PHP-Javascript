<?php
  #include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Registro de motivos solicitados en la tienda
        <small></small>
      </h1>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Verifique los registros de los motivos solicitados en tienda</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="registros" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>NumeroMotivo</th>
                  <th>Codigo Producto</th>
                  <th>PrecioTrabajo</th>
                  <th>FechaInicio</th>
                  <th>FechaFin</th>
                  <th>Cliente</th>
                  <th>AnchoMotivo(cm)</th>
                  <th>LargoMotivo(cm)</th>
                  <th>MariaLuisa</th>
                  <th>Estado</th>
                  <th></th>
                </tr>
                </thead>
                <tbody>
                        <?php
                              try{
                                  $sql = "SELECT id_motivo, num_motivo, codigo_producto, precio_trabajo, fecha_pedido, fecha_entrega, rfc, ancho_motivo, largo_motivo, maria_luisa, estatus";
                                  $sql .= " FROM motivos";
                                  $sql .= " INNER JOIN producto";
                                  $sql .= " ON motivos.id_producto = producto.id_producto";
                                  $sql .= " INNER JOIN cliente";
                                  $sql .= " ON motivos.id_cliente = cliente.id_cliente";
                                  $sql .= " ORDER BY id_motivo";
                                  $resultado = $conn->query($sql);
                              }catch(Exception $e){
                                  $error = $e->getMessage();
                                  echo $error;
                              }
                              while ($barras = $resultado->fetch_assoc() ){ ?>
                                  <tr>
                                      <td><?php echo $barras['num_motivo']; ?></td>
                                      <td><?php echo $barras['codigo_producto']; ?></td>
                                      <td><?php echo $barras['precio_trabajo']; ?></td>
                                      <td><?php echo $barras['fecha_pedido']; ?></td>
                                      <td><?php echo $barras['fecha_entrega']; ?></td>
                                      <td><?php echo $barras['rfc']; ?></td>
                                      <td><?php echo $barras['ancho_motivo'] ?></td>
                                      <td><?php echo $barras['largo_motivo'] ?></td>
                                      <td><?php
                                        if ($barras['maria_luisa'] == 0)
                                          echo 'No tiene';
                                        else
                                          echo 'Si tiene'; ?>
                                       </td>
                                      <td><?php
                                        if ($barras['estatus'] == 0)
                                          echo 'Completado';
                                        else
                                          echo 'No Completado'; ?>
                                       </td>
                                      <td>
                                          <a href="editar-motivo.php?id=<?php echo $barras['id_motivo']; ?>" class="">
                                          Editar
                                          <i class="fa fa-pencil"></i>
                                          <a href="#" data-id="<?php echo $producto['id_barra'];  ?>" data-tipo="categoria" class="borrar_registro">
                                          Eliminar
                                          <i class="fa fa-trash"></i>
                                          </a>
                                      </td>

                                  </tr>
                              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>NumeroMotivo</th>
                  <th>Codigo Producto</th>
                  <th>PrecioTrabajo</th>
                  <th>FechaInicio</th>
                  <th>FechaFin</th>
                  <th>Cliente</th>
                  <th>AnchoMotivo(cm)</th>
                  <th>LargoMotivo(cm)</th>
                  <th>MariaLuisa</th>
                  <th>Estado</th>
                  <th></th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php
        include_once 'templates/footer.php';
  ?>


