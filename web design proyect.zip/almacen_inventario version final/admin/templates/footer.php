<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2021 <a href="#">Pegasos Solutions</a>.</strong> All rights
    reserved.
</footer>

</div>
<!-- .wraper -->

<!-- jQuery 3 -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->

<script src="js/sweetalert2.min.js"></script>

<script src="js/admin-ajax.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/select2.full.min.js"></script>
<script src="js/bootstrap-timepicker.min.js"></script>
<script src="js/fontawesome-iconpicker.min.js"></script>

<script src="js/demo.js"></script>
<script src="js/app.js"></script>
<script src="js/login-ajax.js"></script>

<script src="https://kit.fontawesome.com/52deb4221e.js" crossorigin="anonymous"></script>
</body>
</html>
