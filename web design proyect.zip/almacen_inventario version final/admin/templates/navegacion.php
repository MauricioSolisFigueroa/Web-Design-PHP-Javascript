 <!-- Left side column. contains the sidebar -->
 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">

        <div class="pull-left info">
          <!--<p><?php echo $_SESSION['nombre'];?></p>-->
          <p>Bienvenido Admin</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">Menú de Administración</li>

        <li class="treeview">
          <a href="#">
          <i class="fas fa-barcode"></i>
            <span>Catálogo de Productos</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="catalogo-productos.php"><i class="fa fa-list-ul"></i> Ver Todos</a></li>
            <li><a href="crear-producto.php"><i class="fa fa-plus-circle"></i> Agregar</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
          <i class="fas fa-dolly-flatbed"></i>
            <span>Inventario de Barras</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="inventario-barras.php"><i class="fa fa-list-ul"></i> Ver Todos</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
          <i class="fas fa-boxes"></i>
            <span> Inventario de Pedaceria</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="inventario-pedaceria.php"><i class="fas fa-list-ul"></i> Ver Todos</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-user-circle"></i>
            <span>Catálogo de Clientes</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="catalogo-clientes.php"><i class="fa fa-list-ul"></i> Ver Todos</a></li>
            <li><a href="crear-cliente.php"><i class="fa fa-plus-circle"></i> Agregar</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
          <i class="fas fa-briefcase"></i>
            <span>Registro de Motivos</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="registro-motivos.php"><i class="fa fa-list-ul"></i> Ver Todos</a></li>
            <li><a href="crear-motivo.php"><i class="fa fa-plus-circle"></i> Agregar</a></li>
          </ul>
        </li>        

        <li class="treeview">
          <a href="pedidos-proveedor.php">
            <i class="fa fa-address-card"></i>
            <span>Pedidos a Proveedor</span>
          </a>  
          <ul class="treeview-menu">
            <li><a href="pedidos-proveedor.php"><i class="fa fa-list-ul"></i> Ver Todos</a></li>
            <li><a href="crear-pedido-proveedor.php"><i class="fa fa-plus-circle"></i> Agregar</a></li>
          </ul>
        </li>

        <!--<?php if($_SESSION['nivel'] == 1 ): ?>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i>
            <span>Administradores</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="lista-admin.php"><i class="fa fa-list-ul"></i> Ver Todos</a></li>
            <li><a href="crear-admin.php"><i class="fa fa-plus-circle"></i> Agregar</a></li>
          </ul>
        </li>
        <?php endif; ?>-->

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

<!-- =============================================== -->
